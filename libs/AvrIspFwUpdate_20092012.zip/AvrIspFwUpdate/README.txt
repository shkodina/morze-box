
This is a very simple application for upgrading the firmware of AVR-ISP500-* and RFID-*
devices. After installation the application will automatically start. Follow
the instructions to connect the device, then select the device you're 
upgrading, and hit the "Start" button.



